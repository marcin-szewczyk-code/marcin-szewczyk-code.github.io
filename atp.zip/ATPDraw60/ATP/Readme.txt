This is the default ResultDir where all output end up
This includes the final *.ATP file, intermediate *.DAT, *.PCH *.LIB files, and the result files from ATP simulation *.PL4.
Do NOT store project file *.acp in this folder.
The content of this folder can be deleted.