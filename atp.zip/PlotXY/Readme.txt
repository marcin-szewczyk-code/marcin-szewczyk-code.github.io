*****  Package information  (PlotXY.zip rel Oct.  2012 archive) *****
Contents of the PlotXY.zip archive:
- File PlotXY.exe. The program PlotXY 
- File PlotXWin.exe. The program PlotXWin, that has been added to the packace since 
  June 2005.
- File XYpaper.pdf. Contains a paper published on the EEUG News describing the
  basic ideas under the PlotXY program. It refers to the June 98 release, and
  therefore does not take into account the modifications introduced after that 
  date.
- File HowToUse.pdf. Contains the needed instructions to use the current release 
  of PlotXY/PlotXWin successfully.
- File Conversion.pdf. Contains the rules for converting the variable names when 
  saving variables into a file with a format different from the original one.
- File changes.txt. Contains a short description of the improvements and bug
  corrections made since the June 98 release of the program.
- Files SAMPLE1.ADF, SAMPLE2.ADF and SAMPLE3.ADF containing very simple Ascii Data 
  Files for testing PlotXY functionality with ASCII files, and
- this (readme.txt) file.

*****  Usage license  *****
The November 2009 release of this package may be used in any way, for any purpose, 
at no cost. In may be distributed by any means, provided that the original files 
as supplied by the author remain intact and no charge is made other than for 
reasonable distribution costs.
You do not need to register to use the June 2005 release of ther package, or 
buy a licence to use it.
The package may not be distributed with any commercial product without a prior 
license agreement with the author.

The package is supplied on an as-is basis. The author offers no warranty of its
fitness for any purpose whatsoever, and accepts no liability whatsoever for any 
loss or damage incurred by its use.
The package is not a supported product. The author accepts no commitment or 
liability to address any problems that may be encountered in using it.
However, the program from time to time is developed and improved; therefore comments,
suggestions, bug reports from the users are welcome, preferably at the following 
e-mail address: m.ceraolo@ing.unipi.it
New features are added to new versions of the program keeping in the maximum 
consideration those frequently-requested by the users.

*****************************************
Enjoy your work with PlotXY!
